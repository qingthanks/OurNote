﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q)])]);}; 
var b="rootNodes",c="pageName",d="主页",e="type",f="Wireframe",g="url",h="主页.html",i="children",j="全部便签--item1",k="全部便签--item1.html",l="全部便签--item2",m="全部便签--item2.html",n="全部便签--item3",o="全部便签--item3.html",p="全部便签--新建便签",q="全部便签--新建便签.html";
return _creator();
})();
