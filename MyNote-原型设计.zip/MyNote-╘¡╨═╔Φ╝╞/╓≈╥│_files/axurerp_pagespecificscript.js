for(var i = 0; i < 202; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

if (bIE) document.getElementById('u183').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u183'); });
else {
    document.getElementById('u183').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u183'); }, true);
    document.getElementById('u183').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u183'); }, true);
}

widgetIdToSwipeLeftFunction['u183'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u194','','none',500);

}

}

if (bIE) document.getElementById('u117').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u117'); });
else {
    document.getElementById('u117').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u117'); }, true);
    document.getElementById('u117').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u117'); }, true);
}

widgetIdToSwipeLeftFunction['u117'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u128','','none',500);

}

}

if (bIE) document.getElementById('u153').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u153'); });
else {
    document.getElementById('u153').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u153'); }, true);
    document.getElementById('u153').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u153'); }, true);
}

widgetIdToSwipeLeftFunction['u153'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u164','','none',500);

}

}

if (bIE) document.getElementById('u94').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u94'); });
else {
    document.getElementById('u94').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u94'); }, true);
    document.getElementById('u94').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u94'); }, true);
}

widgetIdToSwipeLeftFunction['u94'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u113','','none',500);

}

}

if (bIE) document.getElementById('u62').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u62'); });
else {
    document.getElementById('u62').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u62'); }, true);
    document.getElementById('u62').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u62'); }, true);
}

widgetIdToSwipeLeftFunction['u62'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u73','','none',500);

}

}

if (bIE) document.getElementById('u168').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u168'); });
else {
    document.getElementById('u168').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u168'); }, true);
    document.getElementById('u168').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u168'); }, true);
}

widgetIdToSwipeLeftFunction['u168'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u179','','none',500);

}

}
gv_vAlignTable['u115'] = 'center';document.getElementById('u132_img').tabIndex = 0;

u132.style.cursor = 'pointer';
$axure.eventManager.click('u132', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u32'] = 'center';document.getElementById('u165_img').tabIndex = 0;

u165.style.cursor = 'pointer';
$axure.eventManager.click('u165', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u7'] = 'top';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u186'] = 'center';gv_vAlignTable['u48'] = 'center';document.getElementById('u105_img').tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	SetPanelVisibility('u109','','none',500);

}
});
gv_vAlignTable['u27'] = 'top';u138.tabIndex = 0;

u138.style.cursor = 'pointer';
$axure.eventManager.click('u138', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u108'] = 'center';document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u11'] = 'top';document.getElementById('u89_img').tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u133'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u68'] = 'top';u176.tabIndex = 0;

u176.style.cursor = 'pointer';
$axure.eventManager.click('u176', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部便签--item2.html');

}
});
gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u10'] = 'center';document.getElementById('u149_img').tabIndex = 0;

u149.style.cursor = 'pointer';
$axure.eventManager.click('u149', function(e) {

if (true) {

	SetPanelVisibility('u198','','none',500);

}
});
gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u112'] = 'top';u44.tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u197'] = 'top';u161.tabIndex = 0;

u161.style.cursor = 'pointer';
$axure.eventManager.click('u161', function(e) {

if (true) {

	self.location.href='全部便签--item1.html';

}
});
gv_vAlignTable['u161'] = 'top';u116.tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if (true) {

	SetPanelState('u0', 'pd2u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u6'] = 'center';document.getElementById('u54_img').tabIndex = 0;

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	SetPanelVisibility('u58','','none',500);

}
});
gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u51'] = 'top';u191.tabIndex = 0;

u191.style.cursor = 'pointer';
$axure.eventManager.click('u191', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部便签--item3.html');

}
});
gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u69'] = 'top';document.getElementById('u77_img').tabIndex = 0;

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u123'] = 'top';document.getElementById('u114_img').tabIndex = 0;

u114.style.cursor = 'pointer';
$axure.eventManager.click('u114', function(e) {

if (true) {

	SetPanelState('u0', 'pd2u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u181'] = 'center';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u40'] = 'center';u139.tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u193'] = 'center';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u65'] = 'center';u84.tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u100'] = 'top';u76.tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	SetPanelVisibility('u73','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u76'] = 'top';document.getElementById('u134_img').tabIndex = 0;

u134.style.cursor = 'pointer';
$axure.eventManager.click('u134', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u200'] = 'center';gv_vAlignTable['u104'] = 'center';document.getElementById('u147_img').tabIndex = 0;

u147.style.cursor = 'pointer';
$axure.eventManager.click('u147', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('全部便签--新建便签.html');

}
});
gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u36'] = 'top';document.getElementById('u39_img').tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
u83.tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u160'] = 'top';document.getElementById('u49_img').tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	SetPanelVisibility('u58','hidden','none',500);

}
});
gv_vAlignTable['u124'] = 'top';document.getElementById('u144_img').tabIndex = 0;

u144.style.cursor = 'pointer';
$axure.eventManager.click('u144', function(e) {

if (true) {

	SetPanelVisibility('u198','hidden','none',500);

}
});
gv_vAlignTable['u80'] = 'center';document.getElementById('u1_img').tabIndex = 0;

u1.style.cursor = 'pointer';
$axure.eventManager.click('u1', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
u167.tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u167'] = 'top';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u72'] = 'center';document.getElementById('u3_img').tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	SetPanelState('u0', 'pd3u0','none','',500,'none','',500);

}
});
